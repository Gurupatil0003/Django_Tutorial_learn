from django.shortcuts import render
import requests
from django.http import JsonResponse
# Create your views here.

def home(request):
    return render(request,"recipes/home.html")

def search(request):
    query=request.GET.get('q',"")
    url=f"https://www.themealdb.com/api/json/v1/1/search.php?s={query}"
    r=requests.get(url).json()
    return JsonResponse(r)

def details(request,id):
    url=f"https://www.themealdb.com/api/json/v1/1/lookup.php?i={id}"
    data=requests.get(url).json()
    return render(request,"recipes/details.html",{"data":data})