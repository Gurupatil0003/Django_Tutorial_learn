
from django.urls import path
from . import views

urlpatterns = [
    path('', views.post_list),
    path('add/', views.add_post),
    path('post/<int:id>/', views.post_detail),
]