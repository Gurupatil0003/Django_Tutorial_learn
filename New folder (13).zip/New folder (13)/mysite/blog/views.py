
from django.shortcuts import render, redirect

# In-memory "database"
POSTS = []

def post_list(request):
    return render(request, 'blog/post_list.html', {'posts': POSTS})

def post_detail(request, id):
    post = POSTS[id]
    return render(request, 'blog/post_detail.html', {'post': post})

def add_post(request):
    if request.method == 'POST':
        title = request.POST.get('title')
        content = request.POST.get('content')
        POSTS.append({'title': title, 'content': content})
        return redirect('/')
    return render(request, 'blog/add_post.html')